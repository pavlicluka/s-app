// Stub file for i18n - prevents circular dependencies during build
export default {};
